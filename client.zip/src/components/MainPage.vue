<template>
  <div>
    <div id="mainpage">
      <NavbarPage />
      <!-- <h1>Main page</h1> -->
      <!-- {{ this.foodData }} -->
      <div class="history-onboarding-filter">
        <button class="mainbtn">메뉴 추첨하기</button>
        <select name="category" class="mainsb">
          <option id="filter" v-for="(i, idx) in this.selectCategory" :key="idx" :value="i" @click="clickCategoryFilter(i)">{{ i }}</option>
        </select>
        <button class="mainbtn onboarding" @click="clickOnboarding">메뉴 등록</button>
      </div>
        <!-- v-if="this.foodData" :list="this.foodData" :stores="this.storesArray" -->
    </div>
    <PaginationPage />
  </div>
</template>

<script>
import NavbarPage from './NavbarPage.vue'
import axios from 'axios'
import PaginationPage from './PaginationPage.vue'

export default {
  name: 'MainPage',
  components: {
    NavbarPage,
    PaginationPage,
},
  data() {
    return {
      foodData: this.$store.state.foodData,
      storesArray: this.$store.state.stores,
      selectCategory: this.$store.state.selectCategory,
      selectedCategory: '',
      keyValue: 0,
      outer: []
    }
  },
  methods: {
    clickOnboarding() {
      axios({
        url: 'http://localhost:3000/shops/getstore',
        headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'Content-Type': 'application/json'
        },
        method: 'get',
        data: null
      }).then((res) => {
        this.$store.commit('getStores', res.data.data)
        this.$router.push('/onboarding')
      })
    },

    clickCategoryFilter(category) {
      this.selectedCategory = category
      
      axios({
        url: 'http://localhost:3000/boards/filter',
        headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'Content-Type': 'application/json'
        },
        method: 'get',
        params: { category: category }
      }).then(async (res) => {
        this.foodData = res.data.data
        this.$store.commit('getFoodData', this.foodData)

        const tempShop = res.data.data
        let tempStores = []
        let values = []

        const shopIdArray = tempShop.map((i) => {
          return i.shop_id
        })

        for(let i = 0; i < shopIdArray.length; i++) {
          tempStores[i] = await axios({
              url: 'http://localhost:3000/shops/main-list',
              headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'Content-Type': 'application/json'
              },
              method: 'get',
              params: shopIdArray[i]
            })     

          values = [...tempStores]
        }

        const lastStores = values.map((i) => {
          return i.data.data[0].store
        })
        this.$store.commit('getStores', lastStores)


        this.$router.push(`/category/${category}`)      
        this.$router.go()

        }).catch((err) => {

          console.log(`err는 ${err}`)
        })
    // end
    }

  },
  // watch: {
  //   foodData: {
  //     handler(val, oldVal) {
  //       console.log('배열변경1')
  //       console.log(`val: ${JSON.stringify(val)}`)
  //       console.log(`oldVal: ${JSON.stringify(oldVal)}`)
  //       this.$store.commit('getFoodData', val)
  //       return this.$store
  //     },
  //     deep: true
  //   },
  //   storesArray(val) {
  //     console.log('배열변경2')
  //     console.log(`val: ${val}`)
  //   }
  // }
}
</script>

<style>
.history-onboarding-filter{
  margin: 80px 250px;
}
.mainbtn{
  margin: 10px;
  border-radius: 5px;
  border: 1px solid black;
  padding: 5px;
  background-color: black;
  color: white;
  font-size: 24px;
}
.mainsb {
  font-family: inherit;  
  background: url('../assets/arrow.png') no-repeat 95% 50%; 
  -webkit-appearance: none; 
  -moz-appearance: none;
  appearance: none;
  margin: 10px;
  border-radius: 5px;
  border: 1px solid black;
  padding: 5px;
  background-color: white;
  color: black;
  font-size: 24px;
  width: 180px;
}

.onboarding {
  float: right;
}

.listWrap {
  text-align: center;
}
</style>