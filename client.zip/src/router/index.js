import VueRouter from 'vue-router'
import LoginPage from '../components/LoginPage.vue'
import UserSignupPage from '../components/UserSignupPage.vue'
import MainPage from '../components/MainPage.vue'
import MyinfoPage from '../components/MyinfoPage.vue'
import store from '../store/store.js'
import ResetPWPage from '../components/ResetPWPage'
import OnboardingPage from '../components/OnboardingPage.vue'
// import DashboardPage from '../components/DashboardPage.vue'

const requireAuth = () => (to, from, next) => {
    if(store.state.isLogin === true) {
        console.log('false 상태')
        return next()
    }else {
        console.log('true 상태!')
        next('/login')
    }
}

const routes = [
    {
        path: '/',
        name: MainPage.name,
        component: MainPage,
        beforeEnter: requireAuth(),
    },
    {
        path: '/category',
        component: MainPage,
        children: [
            {
                path: ':category',
                component: MainPage,
            },   
        ]
    },   
    {
        path: '/create',
        name: UserSignupPage.name,
        component: UserSignupPage
    },
    {
        path: '/reset-pw',
        name: ResetPWPage.name,
        component: ResetPWPage
    },
    {
        path: '/myinfo',
        component: MyinfoPage,
        // children: [
        //     {
        //         path: 'reset-pw',
        //         component: ResetPWPage
        //     }
        // ]
    },
    {
        path: '/login',
        name: LoginPage.name,
        component: LoginPage,
        meta: {
            auth: true
        }
    },
    {
        path: '/onboarding',
        name: OnboardingPage.name,
        component: OnboardingPage
    }
]

const router = new VueRouter({
    mode: 'history',
    routes
})


// router.beforeEach((to, from, next) => {
//     // const isLogin = store.getters[""]
//     if(store.state.isLogin && to.meta.auth) {
//         next()
//     }else {
//         router.push('/login')
//     }
// })



export default router