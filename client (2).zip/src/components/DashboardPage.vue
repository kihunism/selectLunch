<template>
  <div>
    <!-- <router-view /> -->
    dashboard
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>