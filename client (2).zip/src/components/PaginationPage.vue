<template>
  <div>
    <div>
        <div class="listWrap">
            <table class="tablelist">
                <colgroup>
                    <col width="12%" />
                    <col width="*" />
                    <col width="20%" />
                    <col width="12%" />
                    <col width="15%" />
                </colgroup>

                <tr class="thead">
                    <th>카테고리</th>
                    <th>음식</th>
                    <th>가게</th>
                    <th>작성자</th>
                    <th>작성일</th>
                </tr>

                <tr class="tdbody" v-for="(i, idx) in paginatedData" :key="i">
                    <td>{{ i.category }}</td>
                    <td>{{ i.title }}</td>
                    <td>{{ paginatedStoreData[idx] }}</td>
                    <td>{{ i.name }}</td>
                    <td>{{ i.regdate }}</td>
                </tr>
            </table>
            <div>
                <button :disabled="pageNum === 0" @click="prevPage">이전</button>
                <span>{{ pageNum + 1 }} / {{ pageCount }}</span>
                <button :disabled="pageNum >= pageCount - 1" @click="nextPage">다음</button>
            </div>
        </div>

    </div>
  </div>
</template>

<script>
export default {
    name: 'PaginationPage',
    data() {
        return {
            originList: this.$store.state.foodData,
            originStores: this.$store.state.stores,
            pageNum: 0,
            pageSize: 5,
        }
    },
    methods: {
        nextPage() {
            this.pageNum += 1
        },
        prevPage() {
            this.pageNum -= 1
        }

    },
    computed: {
        pageCount() {
            let listLeng = this.originList.length
            let listSize = this.pageSize
            let page = Math.floor(listLeng / listSize)

            if(listLeng % listSize > 0) page += 1

            return page
        },
        paginatedData() {
            const start = this.pageNum * this.pageSize
            const end = start + this.pageSize

            return this.originList.slice(start, end)
        },
        paginatedStoreData() {
            const start = this.pageNum * this.pageSize
            const end = start + this.pageSize

            return this.originStores.slice(start, end)
        }
    }

}
</script>

<style>
.listWrap {
    width: 100%
}

.tablelist {
    width: 100%;
    border-collapse: collapse;
    /* margin: ; */
    
}
.thead {
    font-size: 32px;
    font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
    color: darkblue;
    background-color: black;
    color: white;
}
.tdbody {
    font-size: 20px;
    background-color: aqua;

}
/* .tdtd {
    padding: 10px;
    
} */
th, td {
    border: 1px solid aqua;
    padding: 10px;
}
</style>