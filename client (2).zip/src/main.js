import Vue from 'vue'
import VueRouter from 'vue-router'
import App from './App.vue'
import Vuetify from 'vuetify'
import 'vuetify/dist/vuetify.min.css'
import 'material-design-icons-iconfont/dist/material-design-icons.css'
// import router from './router'
import router from './router/index.js'
import store from '@/store/store.js'

Vue.config.productionTip = false

export default new Vuetify({
  icons: {
    iconfont: 'md' // 'md' || 'mdi' || 'fa' || 'fa4'
  }
})

Vue.use(VueRouter)
Vue.use(Vuetify)

new Vue({
  render: h => h(App),
  router: router,
  store: store
}).$mount('#app')
